var class_distance_g_p2_y0_a41_s_k =
[
    [ "DistanceGP2Y0A41SK", "class_distance_g_p2_y0_a41_s_k.html#ab346b1774a0f4b96d044c593ba32186c", null ],
    [ "getDistanceCentimeter", "class_distance_g_p2_y0_a41_s_k.html#a2f0f8b6df63c05284c8df23a363715d1", null ]
];