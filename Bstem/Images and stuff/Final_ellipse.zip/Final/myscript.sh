#!/bin/bash
# My first script

echo "running script..."
scp (g+e)readings.txt sa@10.42.0.1:/home/sa/Documents/Bstem/plotting/
scp (g,e)readings.txt sa@10.42.0.1://home/sa/Documents/Bstem/plotting/

