var class_distance_g_p2_y0_a21_y_k =
[
    [ "DistanceGP2Y0A21YK", "class_distance_g_p2_y0_a21_y_k.html#a1f7ec1a134c5dcf471a1aa44a8879386", null ],
    [ "getDistanceCentimeter", "class_distance_g_p2_y0_a21_y_k.html#a3f1923b1357c540d9b45eae3650c83e8", null ]
];