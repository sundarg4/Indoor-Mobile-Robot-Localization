from bstem.platform import AdCord
from bstem.platform import Bstem
from datetime import datetime

ad=AdCord()
b=Bstem()

ad.motor[0].speed=0
ad.motor[1].speed=0
ad.motor[2].speed=0
ad.motor[3].speed=0
